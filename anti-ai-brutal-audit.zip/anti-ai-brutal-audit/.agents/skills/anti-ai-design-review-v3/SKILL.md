# Anti-AI Design Review v3 Skill

## Purpose

Audit and improve interfaces so they do not look AI-generated, template-coded, or visually generic.

## Core rule

Do not fix AI-looking design by adding more decoration. Fix it by creating a clearer product-specific design system.

## Detect these AI tells

- Purple/cyan/blue gradient hero sections
- Gradient headline text
- Glassmorphism everywhere
- Blurred orb/blob backgrounds
- `max-w-7xl mx-auto` repeated through every section
- Hero badge + huge centered headline + two CTAs
- Three-card feature grids
- Lucide icons in circular feature badges
- Default shadcn cards/buttons/badges
- `transition-all duration-300`
- Hover-scale on every card
- Framer Motion fade-up/stagger spam
- Generic copy: unlock, seamless, powerful, elevate, revolutionize
- Missing loading, empty, error, offline, stale, disabled states
- Missing reduced-motion and focus-visible handling

## Redesign process

1. Identify AI-looking design tells.
2. Pick a domain-specific design direction.
3. Define semantic tokens.
4. Replace generic surfaces and cards.
5. Replace generic layout rhythm.
6. Rewrite vague copy with domain language.
7. Add real app states.
8. Add reduced-motion and focus states.
9. Verify no functionality was broken.

## Output requirements

Before changing code, write `ui-updates.md` with:

- Findings
- Design direction
- Token plan
- Component plan
- Motion rules
- State-depth plan
- Accessibility plan
- Files to change
- Files not to touch

Never copy a website exactly. Extract principles only.
